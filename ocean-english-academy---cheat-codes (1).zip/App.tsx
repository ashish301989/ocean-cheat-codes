
import React, { useState, useEffect } from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import BookSummary from './components/BookSummary';
import BookInfo from './components/BookInfo';
import BookReview from './components/BookReview';
import Gallery from './components/Gallery';
import VideoSection from './components/VideoSection';
import AuthorSection from './components/AuthorSection';
import DigitalEdition from './components/DigitalEdition';
import SidebarCard from './components/SidebarCard';
import FAQ from './components/FAQ';
import BannerCTA from './components/BannerCTA';
import Footer from './components/Footer';
import AIServiceChat from './components/AIServiceChat';

const App: React.FC = () => {
  return (
    <div className="min-h-screen">
      <div className="hero-gradient overflow-hidden">
        {/* Background Stars */}
        <div className="absolute inset-0 pointer-events-none">
          {[...Array(8)].map((_, i) => (
            <div 
              key={i} 
              className="star" 
              style={{
                width: `${Math.random() * 2}px`,
                height: `${Math.random() * 2}px`,
                top: `${Math.random() * 100}%`,
                left: `${Math.random() * 100}%`,
                '--duration': `${3 + Math.random() * 4}s`
              } as any}
            />
          ))}
        </div>
        
        <Navbar />
        <Hero />
      </div>

      <main className="page-background relative">
        <div className="absolute top-0 left-0 right-0 h-32 bg-gradient-to-b from-[#1a0631] to-transparent opacity-50"></div>
        
        <section className="py-24 px-4 sm:px-6">
          <div className="max-w-7xl mx-auto">
            <div className="flex flex-col lg:flex-row gap-12">
              {/* Content Column */}
              <div className="lg:w-2/3 space-y-6">
                <BookSummary />
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <BookInfo />
                  <BookReview />
                </div>

                <Gallery />
                <VideoSection />
                <AuthorSection />
                <DigitalEdition />
              </div>

              {/* Sidebar Column */}
              <div className="lg:w-1/3">
                <SidebarCard />
              </div>
            </div>

            <FAQ />
          </div>
        </section>

        <section className="pb-24 px-4 sm:px-6">
          <div className="max-w-7xl mx-auto">
            <BannerCTA />
          </div>
        </section>
      </main>

      <Footer />
      
      {/* Floating Global Assistant */}
      <AIServiceChat />
    </div>
  );
};

export default App;
