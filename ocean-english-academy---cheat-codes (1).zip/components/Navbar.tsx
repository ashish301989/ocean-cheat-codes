
import React from 'react';

const Navbar: React.FC = () => {
  return (
    <nav className="sticky top-0 z-50 glass-card border-x-0 border-t-0 rounded-none">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 h-20 flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 gold-gradient rounded-xl flex items-center justify-center text-purple-900 shadow-lg shadow-yellow-500/20">
            <span className="material-symbols-outlined font-bold">menu_book</span>
          </div>
          <div>
            <span className="text-xl font-extrabold tracking-tight text-white block uppercase">Ocean</span>
            <p className="text-[10px] uppercase tracking-[0.2em] text-white/70 -mt-1 font-bold">English Academy</p>
          </div>
        </div>
        
        <div className="hidden md:flex items-center space-x-10">
          <a className="flex items-center space-x-2 text-white/80 hover:text-white transition-colors text-sm font-semibold" href="#">
            <span className="material-symbols-outlined text-[20px]">home</span>
            <span>Home</span>
          </a>
          <a className="flex items-center space-x-2 text-white/80 hover:text-white transition-colors text-sm font-semibold" href="#">
            <span className="material-symbols-outlined text-[20px]">smart_display</span>
            <span>YouTube</span>
          </a>
          <a className="flex items-center space-x-2 text-yellow-400 hover:text-yellow-300 transition-colors text-sm font-semibold" href="#">
            <span className="material-symbols-outlined text-[20px]">chat</span>
            <span>WhatsApp</span>
          </a>
          <button className="gold-gradient text-purple-900 px-6 py-2.5 rounded-full font-bold text-sm shadow-xl hover:scale-105 transition-transform">
            ENROLL NOW
          </button>
        </div>
        
        <button className="md:hidden text-white">
          <span className="material-symbols-outlined text-3xl">menu</span>
        </button>
      </div>
    </nav>
  );
};

export default Navbar;
