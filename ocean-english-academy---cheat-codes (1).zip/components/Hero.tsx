
import React from 'react';

const Hero: React.FC = () => {
  const students = [
    "https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?auto=format&fit=crop&w=150&h=150&q=80",
    "https://images.unsplash.com/photo-1529626455594-4ff0802cfb7e?auto=format&fit=crop&w=150&h=150&q=80",
    "https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=150&h=150&q=80",
    "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=150&h=150&q=80"
  ];

  return (
    <section className="relative pt-12 pb-32 px-4 sm:px-6">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col lg:flex-row items-center gap-12 lg:gap-16">
          <div className="flex-1 text-center lg:text-left z-10">
            <div className="inline-flex items-center space-x-2 py-2 px-4 glass-card rounded-full mb-8 border-white/30">
              <span className="w-2 h-2 rounded-full bg-orange-400 animate-pulse"></span>
              <span className="text-xs font-extrabold uppercase tracking-widest text-white/90">Master Fluency Instantly</span>
            </div>
            
            <h1 className="text-5xl md:text-7xl lg:text-8xl font-black mb-8 leading-[1.1] tracking-tight text-white">
              English <br/>
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-yellow-200 via-orange-400 to-yellow-500">Cheat Codes</span>
            </h1>
            
            <p className="text-xl text-white/80 mb-10 max-w-xl mx-auto lg:mx-0 leading-relaxed font-medium">
              The ultimate cognitive shortcut to natural conversation. No more translating in your head. Just pure, effortless fluency.
            </p>
            
            <div className="flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-6">
              <button className="gold-gradient text-purple-950 px-10 py-5 rounded-2xl font-black text-lg flex items-center justify-center transition-all transform hover:scale-105 hover:shadow-[0_0_30px_rgba(255,209,102,0.4)] shadow-2xl w-full sm:w-auto group">
                BUY NOW
                <span className="material-symbols-outlined ml-2 font-bold group-hover:rotate-12 transition-transform">shopping_cart</span>
              </button>
              <button className="glass-card text-white px-10 py-5 rounded-2xl font-bold text-lg hover:bg-white/20 transition-all border-white/20 w-full sm:w-auto flex items-center justify-center gap-2">
                <span className="material-symbols-outlined text-red-500" style={{ fontVariationSettings: "'FILL' 1" }}>smart_display</span>
                YOUTUBE
              </button>
            </div>
            
            <div className="mt-12 flex flex-wrap items-center justify-center lg:justify-start gap-6 opacity-90">
              <div className="flex -space-x-3">
                {students.map((src, i) => (
                  <img 
                    key={i} 
                    alt="Student" 
                    className="w-12 h-12 rounded-full border-2 border-purple-800 bg-purple-900 object-cover shadow-lg" 
                    src={src} 
                  />
                ))}
              </div>
              <div>
                <p className="text-sm font-bold text-white">Join 25,000+ Students</p>
                <p className="text-[10px] uppercase tracking-widest text-yellow-400 font-black">Urban India's Top Choice</p>
              </div>
            </div>
          </div>
          
          <div className="flex-1 w-full max-w-lg lg:max-w-xl relative">
            <div className="relative group animate-float">
              <div className="absolute -inset-20 bg-orange-500/20 rounded-full blur-[100px] group-hover:bg-orange-500/30 transition-all duration-1000"></div>
              <div className="absolute -inset-20 bg-purple-600/10 rounded-full blur-[120px] top-20 left-20"></div>
              <div className="glass-card p-6 rounded-[2.5rem] border-white/30 relative overflow-hidden flex justify-center items-center">
                <img 
                  alt="CHEAT CODES: The Secret To Fluency" 
                  className="rounded-2xl shadow-2xl w-full max-w-[400px] h-auto object-contain transform transition-transform duration-700 hover:scale-[1.03]" 
                  style={{ filter: 'hue-rotate(245deg) saturate(1.1) contrast(1.1)' }}
                  src="https://lh3.googleusercontent.com/aida-public/AB6AXuCTsGDAoz40Cze2N-5eQYNztaxVlN4LJKI7FbZgcrZy20PdZ9P7QN1-8K6arTvNl89CArMymtSa8X7y-JNTQcbHL3f70jUS50WFjmhlzwBqFV10qLRF4UEMXmiNSyRMaAUKT5IBPAl0EeVz5zYmCvzlCnOpHXxY9FO5m_Iiu_ee4P9SWkuh6T-amTuZzfubKvSX454eaMqY_iX6nRTTiHMY8V4uuEBvjOTxSzehxi3dCx70VgHi6oUwdzsTCfTrLnLQzASpYRceEUXB" 
                />
                <div className="absolute top-4 right-4 glass-card p-4 rounded-2xl shadow-2xl border-white/40 bg-white/10 backdrop-blur-xl">
                  <div className="text-center">
                    <div className="text-yellow-400 font-black text-2xl">4.9</div>
                    <div className="text-[10px] font-bold uppercase tracking-tighter text-white/70">Global Rating</div>
                  </div>
                </div>
                <div className="absolute bottom-4 left-4 gold-gradient p-4 rounded-2xl shadow-2xl text-purple-900 flex items-center gap-2">
                  <span className="material-symbols-outlined text-4xl font-bold">verified_user</span>
                  <div className="leading-none">
                    <div className="text-[10px] font-black uppercase">Official</div>
                    <div className="text-xs font-bold">Best Seller</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
