
import React from 'react';

const Gallery: React.FC = () => {
  const images = [
    "https://lh3.googleusercontent.com/aida-public/AB6AXuB6rpSrGSeAjUledWf_BpjDSUe-aXLpSmsdPaEXCGgX0v8Fvbo2BfcDo6I1cuGbRuAuoS9fesqn-U69ZmGF5fTD98woFRx1x81tSZ0ZB74vNgQz09gac_sIB_ZuWmBUJmcNi2vjOneY84eTHNPiW29mtSR748DDo1FCw4R-fB2byA5CRrls-YNqv3qyXer95iTXA7YPFA1_vkkc8lsCkFcNWUNiLWF9NFcJrahJSLzxWl-jGzIXn7Z22DAZMuCnAdOhq2PQmgnCjeBe",
    "https://lh3.googleusercontent.com/aida-public/AB6AXuCIO5MsFP2eLU_EztgUYQOT5wZJZkjEdYna8DW7P5iDuID3Mwmb-r92FlF_M_i0hDwKGXyhSXA29BZZ2FiZ-jB2pn7Ymf3jNK67LEdCP-0gYraUEDPcYjRMlmD-W7yCgp-Y6Y9K_LH1DJK6f7Py8ZQR_KMh4LLCp-WDaWaFtTEaAPeCV3zoQy1NFnlnBp7kgfi_eiRwtuTT_cyI1on6HFEzeX5WHqBXnPu-16OfaxFbSeQLpr7MjR95MPlYDfiBt0kKB-aBjaTWmbt4",
    "https://lh3.googleusercontent.com/aida-public/AB6AXuAXfWxDk6zVQHZFBn9SGSiVtk6GlmmgQRXTdovVRlu7aM1_dFn5MImro08CqCU6HLdcBesQZHwPgIAaBH0ZZ7gvbw7yrTOEGiWhBUGs7aUwSzKGvgAQQNT2p2wfOd4rBivoOy2rnv_MMuhww4yEeinJtLs8bGWqRpbEfznrolk_6RNFoGQaPWRB0Ltarztk1XrhcsIXb5TR3z7BAwp1xd4rORActnOvZaN9a9FufGZFUV2lzEzFmplIYf-b9RLg-1Ok9jOWcfjMHotI"
  ];

  return (
    <div className="glass-card p-8 rounded-3xl group hover:border-white/50 transition-all">
      <h3 className="text-xl font-bold mb-6 flex items-center gap-2">
        <span className="material-symbols-outlined text-cyan-400">gallery_thumbnail</span>
        Book Gallery
      </h3>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {images.map((src, i) => (
          <div key={i} className="aspect-[3/4] rounded-xl overflow-hidden glass-card">
            <img 
              alt={`Preview ${i + 1}`} 
              className="w-full h-full object-cover opacity-80 hover:opacity-100 transition-opacity" 
              src={src} 
            />
          </div>
        ))}
        <div className="aspect-[3/4] rounded-xl overflow-hidden glass-card flex items-center justify-center bg-white/5 cursor-pointer hover:bg-white/10 transition-colors">
          <span className="text-xs font-bold text-white/60">+12 Pages</span>
        </div>
      </div>
    </div>
  );
};

export default Gallery;
