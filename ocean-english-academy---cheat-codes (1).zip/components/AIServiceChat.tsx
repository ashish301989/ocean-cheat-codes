
import React, { useState } from 'react';
import { getFluencyTip, FluencyResponse } from '../services/gemini';

const AIServiceChat: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<FluencyResponse | null>(null);
  const [topic, setTopic] = useState('');

  const handleGetTip = async () => {
    if (!topic.trim()) return;
    setLoading(true);
    const data = await getFluencyTip(topic);
    setResult(data);
    setLoading(false);
  };

  return (
    <div className="fixed bottom-6 right-6 z-[60] flex flex-col items-end">
      {/* Chat Bubble */}
      {isOpen && (
        <div className="mb-4 w-[320px] sm:w-[380px] glass-card rounded-3xl border-cyan-400/30 shadow-2xl overflow-hidden animate-in fade-in slide-in-from-bottom-4 duration-300">
          <div className="p-5 bg-gradient-to-r from-purple-900 to-indigo-900 border-b border-white/10 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-cyan-400/20 rounded-full flex items-center justify-center border border-cyan-400/30">
                <span className="material-symbols-outlined text-cyan-400 animate-pulse">auto_awesome</span>
              </div>
              <div>
                <h4 className="font-bold text-white text-sm">Aura Assistant</h4>
                <p className="text-[10px] text-cyan-300 uppercase tracking-widest font-black">Magical AI</p>
              </div>
            </div>
            <button 
              onClick={() => setIsOpen(false)}
              className="text-white/50 hover:text-white transition-colors"
            >
              <span className="material-symbols-outlined">close</span>
            </button>
          </div>

          <div className="p-6 space-y-4 max-h-[400px] overflow-y-auto">
            {!result && (
              <p className="text-xs text-white/60 text-center italic">
                "Hi! I'm Aura. Ask me any fluency question and I'll find a magical 'Cheat Code' for you."
              </p>
            )}

            <div className="relative">
              <input 
                type="text" 
                placeholder="Ask Aura anything..."
                value={topic}
                onKeyDown={(e) => e.key === 'Enter' && handleGetTip()}
                onChange={(e) => setTopic(e.target.value)}
                className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-cyan-400/50 transition-colors placeholder:text-white/30 text-white"
              />
              <button 
                onClick={handleGetTip}
                disabled={loading}
                className="absolute right-2 top-2 h-8 w-8 bg-cyan-500 rounded-lg flex items-center justify-center hover:bg-cyan-400 transition-colors disabled:opacity-50"
              >
                {loading ? (
                  <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                ) : (
                  <span className="material-symbols-outlined text-white text-sm">bolt</span>
                )}
              </button>
            </div>

            {result && (
              <div className="space-y-3 animate-in fade-in slide-in-from-bottom-2 duration-500">
                <div className="p-4 bg-cyan-400/10 border border-cyan-400/20 rounded-xl">
                  <p className="text-xs text-cyan-50 leading-relaxed">
                    {result.text}
                  </p>
                </div>
                
                {result.sources && result.sources.length > 0 && (
                  <div className="px-1">
                    <p className="text-[10px] font-bold text-white/40 uppercase tracking-widest mb-2">Aura Sources:</p>
                    <div className="flex flex-wrap gap-2">
                      {result.sources.map((source, i) => (
                        <a 
                          key={i} 
                          href={source.uri} 
                          target="_blank" 
                          rel="noopener noreferrer"
                          className="text-[10px] bg-white/5 hover:bg-white/10 border border-white/10 px-2 py-1 rounded-md text-cyan-300 transition-colors flex items-center gap-1"
                        >
                          <span className="material-symbols-outlined text-[12px]">link</span>
                          {source.title.length > 15 ? source.title.substring(0, 15) + '...' : source.title}
                        </a>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      )}

      {/* Floating Toggle Button */}
      <div className="flex items-center gap-4 group">
        <div className="bg-purple-900/80 backdrop-blur-md px-4 py-2 rounded-full border border-white/10 shadow-xl opacity-0 group-hover:opacity-100 transition-opacity translate-x-2 group-hover:translate-x-0 hidden sm:block">
          <span className="text-xs font-black text-white uppercase tracking-widest">Chat with Aura</span>
        </div>
        <button 
          onClick={() => setIsOpen(!isOpen)}
          className="w-16 h-16 bg-gradient-to-tr from-cyan-400 via-purple-600 to-indigo-600 rounded-full flex items-center justify-center shadow-[0_10px_40px_rgba(34,211,238,0.3)] hover:scale-110 active:scale-95 transition-all group relative overflow-hidden"
        >
          <div className="absolute inset-0 bg-white/20 animate-pulse opacity-0 group-hover:opacity-100 transition-opacity"></div>
          <span className="material-symbols-outlined text-white text-3xl font-black relative z-10">
            {isOpen ? 'close' : 'auto_awesome'}
          </span>
        </button>
      </div>
    </div>
  );
};

export default AIServiceChat;
