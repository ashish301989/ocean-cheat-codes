
import React, { useState, useEffect } from 'react';

const BookSummary: React.FC = () => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [shouldRender, setShouldRender] = useState(false);

  useEffect(() => {
    if (isModalOpen) {
      setShouldRender(true);
      document.body.style.overflow = 'hidden';
    } else {
      const timer = setTimeout(() => setShouldRender(false), 500);
      document.body.style.overflow = 'unset';
      return () => clearTimeout(timer);
    }
  }, [isModalOpen]);

  const toggleModal = () => setIsModalOpen(!isModalOpen);

  return (
    <>
      <div className="glass-card p-8 rounded-3xl group hover:border-white/50 transition-all">
        <div className="flex items-center space-x-4 mb-6">
          <div className="w-12 h-12 gold-gradient rounded-xl flex items-center justify-center text-purple-900 shadow-lg">
            <span className="material-symbols-outlined">lightbulb</span>
          </div>
          <h3 className="text-2xl font-extrabold text-white">Book Summary</h3>
        </div>
        <p className="text-white/80 leading-relaxed text-lg mb-6 line-clamp-3">
          "Cheat Codes" is not just a book; it's a cognitive roadmap to English proficiency. By focusing on high-frequency linguistic patterns and psychology-backed memory techniques, it bypasses the traditional, tedious grammar-first approach. Learn how to think in English and express yourself with the fluidity of a native speaker in record time.
        </p>
        <button 
          onClick={toggleModal}
          className="bg-white/10 hover:bg-white/20 text-white border border-white/20 px-6 py-2.5 rounded-xl font-bold text-sm transition-all flex items-center gap-2 w-fit group"
        >
          <span>VIEW MORE</span>
          <span className="material-symbols-outlined text-yellow-400 group-hover:translate-x-1 transition-transform">arrow_right_alt</span>
        </button>
      </div>

      {/* Full Summary Modal */}
      {shouldRender && (
        <div className={`fixed inset-0 z-[100] flex items-center justify-center p-4 sm:p-6 transition-all duration-500 ${isModalOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}>
          <div 
            className={`absolute inset-0 bg-[#0f041d]/90 backdrop-blur-2xl transition-opacity duration-500 ${isModalOpen ? 'opacity-100' : 'opacity-0'}`}
            onClick={toggleModal}
          ></div>
          
          <div className={`relative w-full max-w-5xl glass-card rounded-[2.5rem] overflow-hidden shadow-[0_30px_100px_rgba(0,0,0,0.5)] border-white/20 flex flex-col max-h-[90vh] transition-all duration-500 ease-[cubic-bezier(0.16,1,0.3,1)] ${isModalOpen ? 'scale-100 translate-y-0 opacity-100' : 'scale-95 translate-y-12 opacity-0'}`}>
            {/* Modal Title Bar */}
            <div className="sticky top-0 z-10 glass-card border-x-0 border-t-0 rounded-none px-8 py-5 flex items-center justify-between backdrop-blur-3xl bg-white/5">
              <h2 className="text-2xl font-black text-white flex items-center gap-3">
                <span className="material-symbols-outlined text-yellow-400">auto_stories</span>
                Book Summary
              </h2>
              <button 
                onClick={toggleModal}
                className="w-10 h-10 rounded-full flex items-center justify-center hover:bg-white/10 transition-colors text-white/50 hover:text-white"
              >
                <span className="material-symbols-outlined">close</span>
              </button>
            </div>

            {/* Modal Content Area */}
            <div className="overflow-y-auto p-8 lg:p-12 custom-scrollbar">
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
                {/* Left Side: Summary Text */}
                <div className={`lg:col-span-7 space-y-6 text-white/90 leading-relaxed text-lg order-2 lg:order-1 transition-all duration-700 delay-100 ${isModalOpen ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'}`}>
                  <p className="font-bold text-yellow-400 text-xl italic mb-4">
                    "In essence, the book serves as a mental operating system for English fluency: faster, lighter, and aligned with how the brain truly learns language."
                  </p>
                  <p>
                    It is designed for learners who want results, not textbooks—clarity, not complexity—and the ability to communicate like a native speaker in significantly less time.
                  </p>
                  <p>
                    <strong className="text-white">Cheat Codes</strong> reframes English learning as a cognitive skill rather than an academic subject. Instead of starting with rigid grammar rules, the book introduces a shortcut-driven system built on high-frequency language patterns—the words, phrases, and structures native speakers use most often. By prioritizing what actually appears in real conversations, it eliminates the inefficiency of memorizing rarely used rules.
                  </p>
                  <p>
                    The core methodology blends linguistics with psychology. Using memory-anchoring techniques, pattern recognition, and repetition loops, the book trains the brain to think in English rather than translate from a native language. This mental shift is positioned as the key differentiator between learners who “know English” and those who can actually speak it fluently.
                  </p>
                  <p>
                    Cheat Codes also challenges the fear and hesitation commonly associated with speaking. Through confidence-building frameworks and practical expression models, it helps readers develop natural sentence flow, intuitive word choice, and conversational rhythm—skills typically acquired only after years of immersion.
                  </p>

                  <div className="pt-8">
                    <button 
                      onClick={toggleModal}
                      className="bg-white/10 hover:bg-white/20 text-white border border-white/20 px-8 py-3 rounded-2xl font-black text-sm transition-all flex items-center gap-2 group"
                    >
                      <span>CLOSE VIEW</span>
                      <span className="material-symbols-outlined text-sm group-hover:-translate-y-1 transition-transform">keyboard_double_arrow_up</span>
                    </button>
                  </div>
                </div>

                {/* Right Side: Thumbnail */}
                <div className={`lg:col-span-5 flex justify-center order-1 lg:order-2 transition-all duration-700 delay-200 ${isModalOpen ? 'opacity-100 scale-100' : 'opacity-0 scale-95'}`}>
                  <div className="relative group">
                    <div className="absolute -inset-4 bg-yellow-400/20 rounded-[2rem] blur-2xl group-hover:bg-yellow-400/30 transition-all"></div>
                    <img 
                      alt="Cheat Codes Book Thumbnail" 
                      className="relative rounded-[2rem] shadow-2xl w-full max-w-[340px] transform hover:scale-[1.02] transition-transform duration-500"
                      style={{ filter: 'hue-rotate(245deg) saturate(1.1) contrast(1.1)' }}
                      src="https://lh3.googleusercontent.com/aida-public/AB6AXuCTsGDAoz40Cze2N-5eQYNztaxVlN4LJKI7FbZgcrZy20PdZ9P7QN1-8K6arTvNl89CArMymtSa8X7y-JNTQcbHL3f70jUS50WFjmhlzwBqFV10qLRF4UEMXmiNSyRMaAUKT5IBPAl0EeVz5zYmCvzlCnOpHXxY9FO5m_Iiu_ee4P9SWkuh6T-amTuZzfubKvSX454eaMqY_iX6nRTTiHMY8V4uuEBvjOTxSzehxi3dCx70VgHi6oUwdzsTCfTrLnLQzASpYRceEUXB"
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default BookSummary;
