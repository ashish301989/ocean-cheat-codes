
import React, { useState } from 'react';

const FAQ: React.FC = () => {
  const [activeIndex, setActiveIndex] = useState<number | null>(0);

  const faqs = [
    {
      q: "Is this book suitable for beginners?",
      a: "Yes! While it covers advanced fluency patterns, the foundational 'cheat codes' are designed to help even beginners start thinking and speaking in natural structures from day one."
    },
    {
      q: "How soon will I get the digital version?",
      a: "Instantly! As soon as your payment is processed, you will receive a download link on your registered email and on the order confirmation page."
    },
    {
      q: "Does it include grammar lessons?",
      a: "Unlike traditional textbooks, we don't focus on boring rules. Instead, we teach 'Intuitive Grammar' – patterns that make correct grammar automatic without you having to think about it."
    },
    {
      q: "What is the Discord community access?",
      a: "You'll get an invite to our private server where you can practice speaking with other students, join weekly live Q&A sessions, and get direct feedback from our academy tutors."
    }
  ];

  const toggleFAQ = (index: number) => {
    setActiveIndex(activeIndex === index ? null : index);
  };

  return (
    <div className="mt-24 max-w-4xl mx-auto">
      <h2 className="text-4xl font-black text-center mb-12">Frequently Asked <span className="text-yellow-400">Questions</span></h2>
      <div className="space-y-4">
        {faqs.map((faq, i) => {
          const isOpen = activeIndex === i;
          return (
            <div key={i} className={`glass-card rounded-3xl overflow-hidden transition-all duration-500 border-white/10 ${isOpen ? 'border-yellow-500/30 shadow-[0_20px_50px_rgba(0,0,0,0.3)]' : 'hover:border-white/30'}`}>
              <button 
                onClick={() => toggleFAQ(i)}
                className="w-full flex items-center justify-between p-6 cursor-pointer text-left focus:outline-none"
              >
                <span className={`text-lg font-bold transition-colors duration-300 ${isOpen ? 'text-yellow-400' : 'text-white'}`}>{faq.q}</span>
                <div className={`w-10 h-10 rounded-full flex items-center justify-center transition-all duration-500 ${isOpen ? 'bg-yellow-400 text-purple-900 rotate-180' : 'bg-white/5 text-yellow-400'}`}>
                  <span className="material-symbols-outlined">expand_more</span>
                </div>
              </button>
              <div 
                className="accordion-content" 
                data-open={isOpen ? "true" : "false"}
              >
                <div className="accordion-inner">
                  <div className="px-6 pb-6 text-white/70 leading-relaxed border-t border-white/5 pt-6 transition-all duration-500">
                    <p className={`transform transition-all duration-500 ${isOpen ? 'translate-y-0 opacity-100' : '-translate-y-4 opacity-0'}`}>
                      {faq.a}
                    </p>
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default FAQ;
