
import React from 'react';

const AuthorSection: React.FC = () => {
  return (
    <div className="glass-card p-8 rounded-3xl group hover:border-white/50 transition-all flex flex-col md:flex-row items-center gap-8">
      <div className="relative flex-shrink-0">
        <img 
          alt="Vidhushi Kaushik" 
          className="w-32 h-32 rounded-3xl border-2 border-white/30 shadow-2xl object-cover transform rotate-3 group-hover:rotate-0 transition-transform" 
          src="https://lh3.googleusercontent.com/aida-public/AB6AXuD9j6eqgWS9IAm5HovdAofgW-JAKV7EbcLUL8BQv4Ayk4hQPh8dflaKfyGtM50vfxxuFocP5l6VqU-al59fPkz8GsrsJr5-t9dQyq2NAgFQ6ADV_VyLm2RFmrtJFniUkIVUM4lKr0lDPDcoenRIOdkOHDjQWvOMIQUbRjIE9glCIhebsbgy51gEL0aKyRqETu3yYVa3L7igFQD1AwKv5GFp5kX8JpvJUdV4hx57yFws_4bsaEpRqNVMiE-6K0kzReaPqMabZ2pjRvNi" 
        />
        <div className="absolute -bottom-2 -right-2 gold-gradient text-purple-900 p-1.5 rounded-lg shadow-lg">
          <span className="material-symbols-outlined text-sm font-bold">verified</span>
        </div>
      </div>
      <div className="flex-1 text-center md:text-left">
        <h3 className="text-2xl font-extrabold mb-1">From The Author</h3>
        <p className="text-yellow-400 font-bold text-sm mb-4 uppercase tracking-widest">Vidhushi Kaushik</p>
        <p className="text-white/80 leading-relaxed mb-6">
          "This book is a collection of secrets I've discovered teaching thousands of students. I wanted to create a guide that feels like a conversation, helping you break through the barriers of hesitation and fear."
        </p>
        <button className="bg-white/10 hover:bg-white/20 text-white border border-white/20 px-6 py-2.5 rounded-xl font-bold text-sm transition-all">
          READ MORE
        </button>
      </div>
    </div>
  );
};

export default AuthorSection;
