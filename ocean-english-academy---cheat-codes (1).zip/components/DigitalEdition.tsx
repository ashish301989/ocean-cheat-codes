
import React from 'react';

const DigitalEdition: React.FC = () => {
  return (
    <div className="glass-card p-8 rounded-3xl group hover:border-white/50 transition-all border-dashed border-2 border-white/20">
      <div className="flex flex-col md:flex-row items-center justify-between gap-6">
        <div className="flex items-center gap-5">
          <div className="w-16 h-16 bg-white/10 rounded-2xl flex items-center justify-center text-red-400">
            <span className="material-symbols-outlined text-4xl">picture_as_pdf</span>
          </div>
          <div>
            <h4 className="text-xl font-bold">Digital Edition (PDF)</h4>
            <p className="text-white/60 text-sm">Download the e-book version for instant access on any device.</p>
          </div>
        </div>
        <button className="bg-white text-purple-900 px-8 py-4 rounded-2xl font-black hover:bg-yellow-400 hover:text-purple-950 transition-all flex items-center gap-3 w-full md:w-auto justify-center">
          DOWNLOAD PDF
          <span className="material-symbols-outlined">download</span>
        </button>
      </div>
    </div>
  );
};

export default DigitalEdition;
