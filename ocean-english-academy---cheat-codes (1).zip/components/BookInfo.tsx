
import React from 'react';

const BookInfo: React.FC = () => {
  const details = [
    { label: 'Pages', value: '248 Premium Pages' },
    { label: 'Language', value: 'English (Global)' },
    { label: 'Format', value: 'Hardcover / PDF' },
    { label: 'Published', value: '2024 Edition' },
  ];

  return (
    <div className="glass-card p-8 rounded-3xl group hover:border-white/50 transition-all">
      <h3 className="text-xl font-bold mb-6 flex items-center gap-2">
        <span className="material-symbols-outlined text-yellow-400">info</span>
        Book Info
      </h3>
      <div className="space-y-4">
        {details.map((item, idx) => (
          <div 
            key={idx} 
            className={`flex justify-between border-white/10 pb-2 ${idx !== details.length - 1 ? 'border-b' : ''}`}
          >
            <span className="text-white/60">{item.label}</span>
            <span className="font-bold">{item.value}</span>
          </div>
        ))}
      </div>
    </div>
  );
};

export default BookInfo;
