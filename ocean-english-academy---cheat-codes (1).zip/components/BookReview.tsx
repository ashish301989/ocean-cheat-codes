
import React from 'react';

const BookReview: React.FC = () => {
  return (
    <div className="glass-card p-8 rounded-3xl group hover:border-white/50 transition-all flex flex-col h-full">
      <h3 className="text-xl font-bold mb-4 flex items-center gap-2">
        <span className="material-symbols-outlined text-orange-400">star</span>
        Book Review
      </h3>
      <div className="flex mb-4">
        {[...Array(5)].map((_, i) => (
          <span key={i} className="material-symbols-outlined text-yellow-400 text-sm" style={{ fontVariationSettings: "'FILL' 1" }}>star</span>
        ))}
      </div>
      <p className="text-white/70 italic text-sm mb-6 leading-relaxed flex-grow">
        "The best investment for my career. The psychological tips on overcoming speaking anxiety were worth the price alone!"
      </p>
      <div className="flex items-center gap-3 mb-6">
        <div className="w-8 h-8 rounded-full bg-purple-500 flex items-center justify-center text-[10px] font-bold">MK</div>
        <span className="text-xs font-bold text-white/90">Mansi Kapoor, Verified Student</span>
      </div>
      <button className="bg-white/10 hover:bg-white/20 text-white border border-white/20 px-6 py-2.5 rounded-xl font-bold text-[10px] uppercase tracking-widest transition-all flex items-center gap-2 w-fit">
        VIEW MORE REVIEW
        <span className="material-symbols-outlined text-sm text-orange-400">open_in_new</span>
      </button>
    </div>
  );
};

export default BookReview;
