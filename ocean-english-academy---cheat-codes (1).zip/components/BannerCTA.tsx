
import React from 'react';

const BannerCTA: React.FC = () => {
  return (
    <div className="flashing-banner glass-card p-1 lg:p-12 rounded-[3rem] border-yellow-500/30 overflow-hidden relative">
      <div className="absolute inset-0 bg-gradient-to-r from-purple-900/50 via-transparent to-purple-900/50"></div>
      <div className="relative z-10 flex flex-col lg:flex-row items-center gap-10 text-center lg:text-left p-8">
        <div className="w-48 lg:w-64 flex-shrink-0 drop-shadow-[0_0_30px_rgba(255,209,102,0.3)] transform -rotate-6 hover:rotate-0 transition-transform duration-500">
          <img 
            alt="Cheat Codes Book" 
            className="rounded-lg shadow-2xl" 
            style={{ filter: 'hue-rotate(245deg) saturate(1.1) contrast(1.1)' }}
            src="https://lh3.googleusercontent.com/aida-public/AB6AXuCTsGDAoz40Cze2N-5eQYNztaxVlN4LJKI7FbZgcrZy20PdZ9P7QN1-8K6arTvNl89CArMymtSa8X7y-JNTQcbHL3f70jUS50WFjmhlzwBqFV10qLRF4UEMXmiNSyRMaAUKT5IBPAl0EeVz5zYmCvzlCnOpHXxY9FO5m_Iiu_ee4P9SWkuh6T-amTuZzfubKvSX454eaMqY_iX6nRTTiHMY8V4uuEBvjOTxSzehxi3dCx70VgHi6oUwdzsTCfTrLnLQzASpYRceEUXB" 
          />
        </div>
        <div className="flex-1">
          <h2 className="text-4xl lg:text-5xl font-black mb-6 leading-tight">
            Stop Dreaming of Fluency. <br/>
            <span className="text-yellow-400">Start Living It.</span>
          </h2>
          <p className="text-xl text-white/80 mb-8 max-w-2xl">
            Grab your copy of "English Cheat Codes" today and unlock the door to global opportunities.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 items-center justify-center lg:justify-start">
            <button className="gold-gradient text-purple-950 px-12 py-5 rounded-2xl font-black text-xl shadow-[0_10px_40px_rgba(255,183,3,0.4)] hover:scale-105 transition-transform">
              BUY NOW - ₹499
            </button>
            <span className="text-sm font-bold opacity-60">*Limited stock available for hardcovers</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BannerCTA;
