
import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="glass-card border-x-0 border-b-0 rounded-none py-16 px-4 sm:px-6 relative z-10">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center gap-10">
        <div className="flex flex-col items-center md:items-start space-y-4">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 gold-gradient rounded-lg flex items-center justify-center text-purple-900 shadow-lg">
              <span className="material-symbols-outlined text-sm font-bold">menu_book</span>
            </div>
            <span className="font-extrabold text-xl uppercase text-white">Ocean English Academy</span>
          </div>
          <p className="text-white/50 text-sm max-w-xs text-center md:text-left">
            Empowering global learners with modern communication shortcuts and psychology-based linguistic techniques.
          </p>
        </div>
        
        <div className="flex space-x-8 text-sm font-bold text-white/80">
          <a className="hover:text-yellow-400 transition-colors" href="#">Privacy</a>
          <a className="hover:text-yellow-400 transition-colors" href="#">Terms</a>
          <a className="hover:text-yellow-400 transition-colors" href="#">Contact</a>
        </div>
        
        <div className="text-center md:text-right">
          <p className="text-white/40 text-[10px] uppercase tracking-widest font-bold">
            © 2024 Ocean English Academy. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
