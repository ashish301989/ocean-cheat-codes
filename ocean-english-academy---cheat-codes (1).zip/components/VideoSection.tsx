
import React from 'react';

const VideoSection: React.FC = () => {
  return (
    <div className="glass-card p-6 rounded-3xl group hover:border-white/50 transition-all">
      <div className="grid grid-cols-1 md:grid-cols-5 gap-6 items-center">
        <div className="md:col-span-3 relative rounded-2xl overflow-hidden aspect-video cursor-pointer">
          <img 
            alt="Video Thumbnail" 
            className="w-full h-full object-cover" 
            src="https://lh3.googleusercontent.com/aida-public/AB6AXuB6rpSrGSeAjUledWf_BpjDSUe-aXLpSmsdPaEXCGgX0v8Fvbo2BfcDo6I1cuGbRuAuoS9fesqn-U69ZmGF5fTD98woFRx1x81tSZ0ZB74vNgQz09gac_sIB_ZuWmBUJmcNi2vjOneY84eTHNPiW29mtSR748DDo1FCw4R-fB2byA5CRrls-YNqv3qyXer95iTXA7YPFA1_vkkc8lsCkFcNWUNiLWF9NFcJrahJSLzxWl-jGzIXn7Z22DAZMuCnAdOhq2PQmgnCjeBe" 
          />
          <div className="absolute inset-0 bg-black/40 flex items-center justify-center group-hover:bg-black/20 transition-all">
            <div className="w-16 h-16 bg-red-600 text-white rounded-full flex items-center justify-center shadow-2xl transform group-hover:scale-110 transition-transform">
              <span className="material-symbols-outlined text-3xl font-black" style={{ fontVariationSettings: "'FILL' 1" }}>play_arrow</span>
            </div>
          </div>
          <div className="absolute bottom-3 left-3 flex items-center gap-2">
            <span className="bg-red-600 px-2 py-0.5 rounded text-[8px] font-bold">YOUTUBE</span>
            <span className="text-[10px] font-bold shadow-sm">Sneak Peek</span>
          </div>
        </div>
        <div className="md:col-span-2 flex flex-col justify-center text-center md:text-left">
          <h4 className="text-2xl font-black mb-3 leading-tight text-white">Master Fluency Secrets</h4>
          <p className="text-white/70 text-sm mb-6">See the real transformation of students using these cheat codes.</p>
          <a className="inline-flex items-center justify-center md:justify-start gap-2 text-red-400 font-bold hover:text-red-300 transition-colors group" href="#">
            <span>Watch more on YouTube</span>
            <span className="material-symbols-outlined text-lg transition-transform group-hover:translate-x-1">arrow_forward</span>
          </a>
        </div>
      </div>
    </div>
  );
};

export default VideoSection;
