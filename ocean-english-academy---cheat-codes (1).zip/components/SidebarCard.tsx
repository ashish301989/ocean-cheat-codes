
import React from 'react';

const SidebarCard: React.FC = () => {
  const benefits = [
    'English Cheat Codes E-Book',
    'Lifetime Updates',
    'Bonus: Phrase Master Guide',
    'Community Discord Access',
  ];

  return (
    <div className="sticky top-28 glass-card rounded-[2.5rem] p-8 border-white/40 shadow-2xl shadow-black/30">
      <div className="flex justify-between items-start mb-8">
        <div>
          <span className="bg-white/20 px-3 py-1 rounded-full text-[10px] font-black tracking-widest uppercase mb-4 inline-block">Flash Sale</span>
          <h3 className="text-3xl font-black text-white">Get Access</h3>
        </div>
        <div className="text-right">
          <div className="text-white/50 line-through text-lg font-bold">₹1,999</div>
          <div className="text-4xl font-black text-yellow-400">₹499</div>
        </div>
      </div>
      
      <div className="space-y-4 mb-10">
        {benefits.map((benefit, i) => (
          <div key={i} className="flex items-center space-x-3 text-white/80 font-medium">
            <span className="material-symbols-outlined text-yellow-400">check_circle</span>
            <span>{benefit}</span>
          </div>
        ))}
      </div>
      
      <button className="w-full gold-gradient text-purple-950 py-5 rounded-2xl font-black text-xl shadow-xl hover:scale-[1.02] active:scale-[0.98] transition-all mb-6">
        BUY THE BOOK NOW
      </button>
      
      <div className="flex items-center justify-center space-x-4 opacity-60">
        <span className="material-symbols-outlined">security</span>
        <span className="text-xs font-bold uppercase tracking-wider">Secure 256-bit Payment</span>
      </div>
    </div>
  );
};

export default SidebarCard;
