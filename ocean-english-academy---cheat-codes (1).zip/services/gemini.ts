
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export interface FluencyResponse {
  text: string;
  sources?: Array<{ title: string; uri: string }>;
}

export const getFluencyTip = async (topic: string): Promise<FluencyResponse> => {
  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `You are an English Fluency Coach for Ocean English Academy.
      The user is asking about: "${topic}".
      Provide a specific, actionable "Cheat Code" (a cognitive shortcut or linguistic pattern) for this topic.
      If it's about slang, trends, or common usage, use Google Search to find the absolute latest examples from 2024-2025.
      Keep the response brief (under 50 words).`,
      config: {
        tools: [{ googleSearch: {} }],
        temperature: 0.7,
        maxOutputTokens: 250,
      }
    });

    const text = response.text || "Try connecting phrases with 'actually' or 'honestly' to sound more natural instantly!";
    const groundingChunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks;
    
    const sources = groundingChunks?.map((chunk: any) => ({
      title: chunk.web?.title || 'Source',
      uri: chunk.web?.uri || '#'
    })).filter((s: any) => s.uri !== '#');

    return { text, sources };
  } catch (error) {
    console.error("Gemini Error:", error);
    return { 
      text: "The best cheat code is to stop translating in your head and start feeling the rhythm of the sentence." 
    };
  }
};
